# webglserver
Basic WebGL Server in Java Script

BASIC WEBGL MULTIPLAYER ONLINE CLIENT (HTML5)
soon on unity asset store!

this Server is powerful WebGL mmo template created special for multiplayer online games in html5. 
 Features: 

About unity WebGL client

 - Easy to send and receive messages from a nodeJS server
  
 - Complete example scene.

 - Easy to read and understand code.

 - Optimized Code (C#).

 - Script comments.

 - Easy to deploy the game in any cloud service

* Play now WebGL Game Demo: http://bit.ly/webglmmo

* Check out our online documentation for more information:
 https://drive.google.com/openid=1j2qdfMP917Kxkze8cqUwcO_06gtP75Sd
